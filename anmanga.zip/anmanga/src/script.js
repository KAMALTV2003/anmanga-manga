// وظيفة السحب للأسفل
function scrollToContent() {
  document.getElementById("content").scrollIntoView({ behavior: "smooth" });
}
